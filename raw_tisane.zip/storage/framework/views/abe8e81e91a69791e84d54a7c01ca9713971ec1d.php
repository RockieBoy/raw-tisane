

<?php $__env->startSection('content'); ?>
<h1>Stok Bahan-Bahan</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rawherbal\resources\views/stok.blade.php ENDPATH**/ ?>