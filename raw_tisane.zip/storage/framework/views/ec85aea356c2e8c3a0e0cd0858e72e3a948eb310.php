

<?php $__env->startSection('content'); ?>
<h1>Selamat Datang di Aplikasi Raw Herbal</h1>
<div class="table-responsive">
    <table class="table table-center card-table table-striped">
        <thead>
            <tr>
                <th>Foto Bahan</th>
                <th>Nama Bahan</th>
                <th>Jenis Bahan</th>
                <th>Jumlah Stok (Kg)</th>
            </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e(asset('storage/'. $bahan->foto)); ?>" width="100px">
                </td>
                <td><?php echo e($bahan->nm_bahan); ?></td>
                <td><?php echo e($bahan->jenisBahan->nama); ?></td>
                <td><?php echo e($bahan->stok); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rawherbal\resources\views//welcome.blade.php ENDPATH**/ ?>