

<!-- Mengubah judul -->
<?php
$title = "Data Stok Aksesoris";
$preTitle = "Semua Data";
?>

<?php $__env->startPush('page-action'); ?>
<a href="<?php echo e(route('aksesoris.create')); ?>" class="btn btn-primary">+ Tambah Data Aksesoris</a>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="row mb-5">
    <form class="d-flex" action="/search" method="GET">
        <?php echo csrf_field(); ?>
        <input type="text" class="form-control me-2" name="cari" placeholder="Silahkan cari data yang diperlukan disini" aria-label="Cari">
        <input type="submit" value="Cari Data" id="" class="btn btn-outline-success">
    </form>
</div>

<div class="table-responsive">
    <table class="table table-center card-table table-striped">
        <thead>
            <tr>
                <th>Foto Aksesoris</th>
                <th>Nama Aksesoris</th>
                <th>Ukuran Aksesoris</th>
                <th>Satuan Aksesoris</th>
                <th>Warna Aksesoris</th>
                <th>Jumlah Stok</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $aksesoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aksesoris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e(asset('/data_file/aksesoris/'. $aksesoris->foto)); ?>" width="100px">
                </td>
                <td><?php echo e($aksesoris->nama); ?></td>
                <td><?php echo e($aksesoris->ukuran); ?></td>
                <td><?php echo e($aksesoris->satuan); ?></td>
                <td><?php echo e($aksesoris->warna); ?></td>
                <td><?php echo e($aksesoris->stok); ?></td>
                <td>
                    <form action="<?php echo e(route('aksesoris.destroy', $aksesoris->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a href="<?php echo e(route('aksesoris.edit', $aksesoris->id)); ?>" class="btn btn-primary">Edit</a>
                        <input type="submit" value="Hapus" class="btn btn-danger">
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 3\PBO\Rawherbal\resources\views/aksesoris/index.blade.php ENDPATH**/ ?>