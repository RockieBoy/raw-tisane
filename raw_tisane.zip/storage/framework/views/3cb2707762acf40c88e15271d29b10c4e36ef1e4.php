                    <?php if(session('succes')): ?>
                    <div class="alert alert-success" role="alert"><?php echo e(session('succes')); ?></div>
                    <?php endif; ?>

                    <?php if(session('info')): ?>
                    <div class="alert alert-info" role="alert"><?php echo e(session('info')); ?></div>
                    <?php endif; ?>
                    
                    <?php if(session('danger')): ?>
                    <div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
                    <?php endif; ?>
                    
<?php /**PATH D:\Kuliah\Semester 3\PBO\Rawherbal\resources\views/templates/partials/alert.blade.php ENDPATH**/ ?>