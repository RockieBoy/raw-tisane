

<!-- Mengubah judul -->
<?php
$title = "Data Bahan-Bahan";
$preTitle = "Semua Data";
?>

<?php $__env->startPush('page-action'); ?>
<a href="<?php echo e(route('bahan.create')); ?>" class="btn btn-primary">+ Tambah Data Bahan</a>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<div class="table-responsive">
    <table class="table table-center card-table table-striped">
        <thead>
            <tr>
                <th>Foto Bahan</th>
                <th>Nama Bahan</th>
                <th>Jenis Bahan</th>
                <th>Jumlah Stok (Kg)</th>
                <th>Nomor Container</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e(url('/data_file/bahan/'.$bahan-> foto)); ?>" width="100px">
                </td>
                <td><?php echo e($bahan->nm_bahan); ?></td>
                <td><?php echo e($bahan->jenisBahan->nama); ?></td>
                <td><?php echo e($bahan->stok); ?></td>
                <td><?php echo e($bahan->nomor_container); ?></td>
                <td>
                    <form action="<?php echo e(route('bahan.destroy', $bahan->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a href="<?php echo e(route('bahan.edit', $bahan->id)); ?>" class="btn btn-primary">Edit</a>
                        <input type="submit" value="Hapus" class="btn btn-danger">
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rawherbal\resources\views/bahan/index.blade.php ENDPATH**/ ?>